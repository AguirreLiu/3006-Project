'use strict'

const mongoose = require('mongoose')
const schema = require('./schema')

mongoose.connect("mongodb://127.0.0.1:27017/chat")

const Message = mongoose.connection.model('Message', schema)

function setRecord(msgItem) {
  const { name, room, uid, sid, ts: time, namecolor, msgcolor, msg } = msgItem
  const m = new Message({
    name,
    room,
    uid,
    sid,
    time,
    namecolor,
    msgcolor,
    msg
  })
  m.save()
}

function getRecordByName(user_name, limit=100) {
  console.log('user_name : ' + user_name)
  return Message
          .find({ name: user_name }, '-_id -__v')
          .sort({ time: 'desc'})
          .limit(+limit)
          .exec()
}


function getRecord(roomId, limit=100) {
  return Message.find({ room: roomId }, '-_id -__v').sort({time: 'desc'}).limit(+limit)
          .exec()
}


module.exports = {
  getRecord,
  setRecord,
  getRecordByName
}