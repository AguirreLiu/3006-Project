'use strict'

const mongoose = require('mongoose');
 
module.exports = new mongoose.Schema({
  name  :       { type: String, required: true,default:"" },
  room  :       { type: String, required: true ,default:"" },
  uid   :        { type: String, required: true ,default:"" },
  sid   :        { type: String, required: true ,default:"" },
  time      :       { type: Number, required: true },
  namecolor :  { type: String ,default:"" },
  msgcolor  :   { type: String ,default:"" },
  msg       :   { type: String, required: true ,default:"" }
}, { collection: 'tb_msg', versionKey: false }

);